%w( rubygems spec dm-core dm-validations).each { |lib| require lib }
require 'lib/rtt'
Dir['lib/rtt/*'].each { |lib| require lib }
